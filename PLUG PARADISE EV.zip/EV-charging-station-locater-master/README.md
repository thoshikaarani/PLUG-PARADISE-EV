# EV-charging-station-locater
## EV charging:
EV charging involves supply of direct current (DC) to the battery pack. As electricity distribution systems supply alternate current (AC) power, a converter is required to provide DC power to the battery.<br>
The website aims at providing a user-friendly interface which can be accessed by any user without any limitations. Since the use of Electric vehicles have been increased the need for station locators have become a neccessaary aspect to travel through without any hassels. The website provides assistance in finding the best possible station in and around the place specified.
# Home Page

![WhatsApp Image 2022-10-16 at 2 52 58 PM](https://user-images.githubusercontent.com/92366931/196028187-0cae488a-f6e0-4026-bd5a-3496d294f796.jpeg)
![WhatsApp Image 2022-10-16 at 2 54 27 PM](https://user-images.githubusercontent.com/92366931/196028194-fc2634f7-b4f5-43c0-bdba-30b79d854dd8.jpeg)
![WhatsApp Image 2022-10-16 at 2 56 04 PM (1)](https://user-images.githubusercontent.com/92366931/196028332-1e804a8e-d9f1-4cad-80c3-3d5ed14601fb.jpeg)

# Features of the website

### 1.EV Charging Locator

The main feature of the website which enables easy access to EV charging station in and around the location the user enters.

![WhatsApp Image 2022-10-16 at 3 11 34 PM](https://user-images.githubusercontent.com/92366931/196028704-2683fd07-ddd0-4eea-83ad-e761720fc5c1.jpeg)

### 2.Map Routing

The feature of the website which enables the user to enroute his journey by specifing the his current loction and the the destination. 

![WhatsApp Image 2022-10-16 at 3 13 23 PM](https://user-images.githubusercontent.com/92366931/196028735-4f6ec2fe-23df-4863-bfba-46d40885c554.jpeg)

### 3. Traffic Detection

The feature of the website which determines the current traffic status around the specified loction based on the the radius of area mentioned by the user. 

![WhatsApp Image 2022-10-16 at 3 16 13 PM](https://user-images.githubusercontent.com/92366931/196028829-578cb152-0f60-40e6-a72c-dcf76de4b5cf.jpeg)

##### The above three features illustrated above depicts the three stages from which the user can inherit the needed information about the electric charging station and find the best route to reach the EV charging station from the website 

